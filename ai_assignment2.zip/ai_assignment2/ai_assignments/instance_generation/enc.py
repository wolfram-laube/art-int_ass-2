# this is the common encoding for different level tiles
WALL = 1
SPACE = 0
EXPOSED = -1
UNDETERMINED = -2
